var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.2",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "PPI_praw",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(192,192,192)",
      "height" : 60.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 25,
      "border-color" : "rgb(204,204,204)",
      "background-opacity" : 1.0,
      "width" : 150.0,
      "text-opacity" : 1.0,
      "border-width" : 20.0,
      "shape" : "ellipse",
      "color" : "rgb(0,0,0)",
      "content" : "data(query_term)"
    }
  }, {
    "selector" : "node[FoldChange > 100]",
    "css" : {
      "background-color" : "rgb(178,24,43)"
    }
  }, {
    "selector" : "node[FoldChange = 100]",
    "css" : {
      "background-color" : "rgb(214,96,77)"
    }
  }, {
    "selector" : "node[FoldChange > 0][FoldChange < 100]",
    "css" : {
      "background-color" : "mapData(FoldChange,0,100,rgb(247,247,247),rgb(214,96,77))"
    }
  }, {
    "selector" : "node[FoldChange > -100][FoldChange < 0]",
    "css" : {
      "background-color" : "mapData(FoldChange,-100,0,rgb(67,147,195),rgb(247,247,247))"
    }
  }, {
    "selector" : "node[FoldChange = -100]",
    "css" : {
      "background-color" : "rgb(67,147,195)"
    }
  }, {
    "selector" : "node[FoldChange < -100]",
    "css" : {
      "background-color" : "rgb(33,102,172)"
    }
  }, {
    "selector" : "node[pvalue > 0.05]",
    "css" : {
      "border-color" : "rgb(68,1,84)"
    }
  }, {
    "selector" : "node[pvalue = 0.05]",
    "css" : {
      "border-color" : "rgb(68,2,86)"
    }
  }, {
    "selector" : "node[pvalue > 0.01][pvalue < 0.05]",
    "css" : {
      "border-color" : "mapData(pvalue,0.01,0.05,rgb(33,145,140),rgb(68,2,86))"
    }
  }, {
    "selector" : "node[pvalue > 0][pvalue < 0.01]",
    "css" : {
      "border-color" : "mapData(pvalue,0,0.01,rgb(251,231,35),rgb(33,145,140))"
    }
  }, {
    "selector" : "node[pvalue = 0]",
    "css" : {
      "border-color" : "rgb(251,231,35)"
    }
  }, {
    "selector" : "node[pvalue < 0]",
    "css" : {
      "border-color" : "rgb(253,231,37)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "width" : 2.0,
      "source-arrow-shape" : "none",
      "font-size" : 10,
      "line-color" : "rgb(31,41,61)",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "content" : ""
    }
  }, {
    "selector" : "edge[stringdb_score > 1]",
    "css" : {
      "width" : 4.0
    }
  }, {
    "selector" : "edge[stringdb_score = 1]",
    "css" : {
      "width" : 4.0
    }
  }, {
    "selector" : "edge[stringdb_score > 0.5][stringdb_score < 1]",
    "css" : {
      "width" : "mapData(stringdb_score,0.5,1,2.0,4.0)"
    }
  }, {
    "selector" : "edge[stringdb_score > 0.2][stringdb_score < 0.5]",
    "css" : {
      "width" : "mapData(stringdb_score,0.2,0.5,0.8,2.0)"
    }
  }, {
    "selector" : "edge[stringdb_score = 0.2]",
    "css" : {
      "width" : 0.8
    }
  }, {
    "selector" : "edge[stringdb_score < 0.2]",
    "css" : {
      "width" : 0.8
    }
  }, {
    "selector" : "edge[stringdb_score > 1]",
    "css" : {
      "opacity" : 0.6666666666666666
    }
  }, {
    "selector" : "edge[stringdb_score = 1]",
    "css" : {
      "opacity" : 0.6666666666666666
    }
  }, {
    "selector" : "edge[stringdb_score > 0.5][stringdb_score < 1]",
    "css" : {
      "opacity" : "mapData(stringdb_score,0.5,1,85,170)"
    }
  }, {
    "selector" : "edge[stringdb_score > 0.2][stringdb_score < 0.5]",
    "css" : {
      "opacity" : "mapData(stringdb_score,0.2,0.5,34,85)"
    }
  }, {
    "selector" : "edge[stringdb_score = 0.2]",
    "css" : {
      "opacity" : 0.13333333333333333
    }
  }, {
    "selector" : "edge[stringdb_score < 0.2]",
    "css" : {
      "opacity" : 0.13333333333333333
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.2",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "PPI_padj",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(192,192,192)",
      "height" : 60.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 25,
      "border-color" : "rgb(204,204,204)",
      "background-opacity" : 1.0,
      "width" : 150.0,
      "text-opacity" : 1.0,
      "border-width" : 20.0,
      "shape" : "ellipse",
      "color" : "rgb(0,0,0)",
      "content" : "data(display_name)"
    }
  }, {
    "selector" : "node[FoldChange > 100]",
    "css" : {
      "background-color" : "rgb(178,24,43)"
    }
  }, {
    "selector" : "node[FoldChange = 100]",
    "css" : {
      "background-color" : "rgb(214,96,77)"
    }
  }, {
    "selector" : "node[FoldChange > 0][FoldChange < 100]",
    "css" : {
      "background-color" : "mapData(FoldChange,0,100,rgb(247,247,247),rgb(214,96,77))"
    }
  }, {
    "selector" : "node[FoldChange > -100][FoldChange < 0]",
    "css" : {
      "background-color" : "mapData(FoldChange,-100,0,rgb(67,147,195),rgb(247,247,247))"
    }
  }, {
    "selector" : "node[FoldChange = -100]",
    "css" : {
      "background-color" : "rgb(67,147,195)"
    }
  }, {
    "selector" : "node[FoldChange < -100]",
    "css" : {
      "background-color" : "rgb(33,102,172)"
    }
  }, {
    "selector" : "node[padj > 0.05]",
    "css" : {
      "border-color" : "rgb(68,1,84)"
    }
  }, {
    "selector" : "node[padj = 0.05]",
    "css" : {
      "border-color" : "rgb(68,2,86)"
    }
  }, {
    "selector" : "node[padj > 0.01][padj < 0.05]",
    "css" : {
      "border-color" : "mapData(padj,0.01,0.05,rgb(33,145,140),rgb(68,2,86))"
    }
  }, {
    "selector" : "node[padj > 0][padj < 0.01]",
    "css" : {
      "border-color" : "mapData(padj,0,0.01,rgb(251,231,35),rgb(33,145,140))"
    }
  }, {
    "selector" : "node[padj = 0]",
    "css" : {
      "border-color" : "rgb(251,231,35)"
    }
  }, {
    "selector" : "node[padj < 0]",
    "css" : {
      "border-color" : "rgb(253,231,37)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "width" : 2.0,
      "source-arrow-shape" : "none",
      "font-size" : 10,
      "line-color" : "rgb(31,41,61)",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "content" : ""
    }
  }, {
    "selector" : "edge[stringdb_score > 1]",
    "css" : {
      "width" : 4.0
    }
  }, {
    "selector" : "edge[stringdb_score = 1]",
    "css" : {
      "width" : 4.0
    }
  }, {
    "selector" : "edge[stringdb_score > 0.5][stringdb_score < 1]",
    "css" : {
      "width" : "mapData(stringdb_score,0.5,1,2.0,4.0)"
    }
  }, {
    "selector" : "edge[stringdb_score > 0.2][stringdb_score < 0.5]",
    "css" : {
      "width" : "mapData(stringdb_score,0.2,0.5,0.8,2.0)"
    }
  }, {
    "selector" : "edge[stringdb_score = 0.2]",
    "css" : {
      "width" : 0.8
    }
  }, {
    "selector" : "edge[stringdb_score < 0.2]",
    "css" : {
      "width" : 0.8
    }
  }, {
    "selector" : "edge[stringdb_score > 1]",
    "css" : {
      "opacity" : 0.6666666666666666
    }
  }, {
    "selector" : "edge[stringdb_score = 1]",
    "css" : {
      "opacity" : 0.6666666666666666
    }
  }, {
    "selector" : "edge[stringdb_score > 0.5][stringdb_score < 1]",
    "css" : {
      "opacity" : "mapData(stringdb_score,0.5,1,85,170)"
    }
  }, {
    "selector" : "edge[stringdb_score > 0.2][stringdb_score < 0.5]",
    "css" : {
      "opacity" : "mapData(stringdb_score,0.2,0.5,34,85)"
    }
  }, {
    "selector" : "edge[stringdb_score = 0.2]",
    "css" : {
      "opacity" : 0.13333333333333333
    }
  }, {
    "selector" : "edge[stringdb_score < 0.2]",
    "css" : {
      "opacity" : 0.13333333333333333
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.2",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(137,208,245)",
      "height" : 35.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 12,
      "border-color" : "rgb(204,204,204)",
      "background-opacity" : 1.0,
      "width" : 75.0,
      "text-opacity" : 1.0,
      "border-width" : 0.0,
      "shape" : "roundrectangle",
      "color" : "rgb(0,0,0)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "width" : 2.0,
      "source-arrow-shape" : "none",
      "font-size" : 10,
      "line-color" : "rgb(132,132,132)",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "content" : ""
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]